// src/pages/Users.jsx

function Users() {
  return (
    <div>
      <h1>Gestión de Usuarios</h1>
      <p>Aquí irán los usuarios del sistema.</p>
    </div>
  );
}

export default Users;
