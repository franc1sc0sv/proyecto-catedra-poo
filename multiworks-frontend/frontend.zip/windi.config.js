export default {
  extract: {
    include: ['index.html', 'src/**/*.{jsx,js}']
  }
}
